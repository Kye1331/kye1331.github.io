# Compression Libraries

<!-- ## Extract7z.js

## Extractzip.js -->

## Libunrar.js

Emscripten port of RARLab's open-source unrar library

Source: https://github.com/tnikolai2/libunrar-js
